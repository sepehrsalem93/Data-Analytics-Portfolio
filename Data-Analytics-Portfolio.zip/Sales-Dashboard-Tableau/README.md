# Sales Dashboard Project

Built an interactive Tableau dashboard to visualize sales trends, product performance, and customer demographics.  
Enabled real-time decision-making through dynamic filtering and region-based breakdowns.  
Tools: Tableau