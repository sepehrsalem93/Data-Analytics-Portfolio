# SQL Performance Reports

Created SQL queries to generate sales performance summaries by region.  
Supported quarterly business review reporting.  
Tools: MySQL / PostgreSQL