# Sales Forecasting Project

Forecasted future sales using ARIMA time-series modeling in R.  
Analyzed 3 years of monthly sales data to predict the next year's demand.  
Tools: R, Forecast package, ggplot2