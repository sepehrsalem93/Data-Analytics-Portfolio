# Customer Churn Analysis

Built a Random Forest model to predict customer churn based on usage patterns.  
Improved early detection of churn risk by analyzing behavioral factors.  
Tools: Python, scikit-learn, pandas